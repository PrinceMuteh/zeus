<style>
.activity-log {
    display: none;
}
</style>
<div class="activity-log">
    <div class="container-fluid" style="border-top: 1px solid #ccc;">
        <!-- text-inter -->
        <div class="container-fluid">
            <div class="row mt-4">
                <div class="col-sm-6 col-md-12 col-lg-8">
                    <div class="scroll-activity">
                        <div class="activity-left mb-3">
                            <div class="side-activity">
                                <span class="week-day">Wednesday</span>
                                <span class="month-day">December 18</span>
                            </div>
                            <div class="info-activity">
                                <div class="info-info">
                                    <div class="info-icon">
                                        <div class="icon-notice bg-light-blue">
                                            <img src="{{ asset('assets/images/notice.svg') }}" alt="" />
                                        </div>
                                    </div>
                                    <div class="info-desc">
                                        <span class="infoTop">
                                            New Vehicle added by Prince Masud
                                        </span>
                                        <span class="infoButtom">16 May, 2022 @ 04:35</span>
                                    </div>
                                </div>
                                <div class="info-info">
                                    <div class="info-icon">
                                        <div class="icon-notice bg-light-blue">
                                            <img src="{{ asset('assets/images/notice.svg') }}" alt="" />
                                        </div>
                                    </div>
                                    <div class="info-desc">
                                        <span class="infoTop">
                                            New Vehicle added by Prince Masud
                                        </span>
                                        <span class="infoButtom">16 May, 2022 @ 04:35</span>
                                    </div>
                                </div>
                                <div class="info-info">
                                    <div class="info-icon">
                                        <div class="icon-notice bg-light-blue">
                                            <img src="{{ asset('assets/images/notice.svg') }}" alt="" />
                                        </div>
                                    </div>
                                    <div class="info-desc">
                                        <span class="infoTop">
                                            New Vehicle added by Prince Masud
                                        </span>
                                        <span class="infoButtom">16 May, 2022 @ 04:35</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="activity-left mb-3">
                            <div class="side-activity">
                                <span class="week-day">Wednesday</span>
                                <span class="month-day">December 18</span>
                            </div>
                            <div class="info-activity">
                                <div class="info-info">
                                    <div class="info-icon">
                                        <div class="icon-notice bg-light-blue">
                                            <img src="{{ asset('assets/images/notice.svg') }}" alt="" />
                                        </div>
                                    </div>
                                    <div class="info-desc">
                                        <span class="infoTop">
                                            New Vehicle added by Prince Masud
                                        </span>
                                        <span class="infoButtom">16 May, 2022 @ 04:35</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="activity-left mb-3">
                            <div class="side-activity">
                                <span class="week-day">Wednesday</span>
                                <span class="month-day">December 18</span>
                            </div>
                            <div class="info-activity">
                                <div class="info-info">
                                    <div class="info-icon">
                                        <div class="icon-notice bg-light-blue">
                                            <img src="{{ asset('assets/images/notice.svg') }}" alt="" />
                                        </div>
                                    </div>
                                    <div class="info-desc">
                                        <span class="infoTop">
                                            New Vehicle added by Prince Masud
                                        </span>
                                        <span class="infoButtom">16 May, 2022 @ 04:35</span>
                                    </div>
                                </div>
                                <div class="info-info">
                                    <div class="info-icon">
                                        <div class="icon-notice bg-light-blue">
                                            <img src="{{ asset('assets/images/notice.svg') }}" alt="" />
                                        </div>
                                    </div>
                                    <div class="info-desc">
                                        <span class="infoTop">
                                            New Vehicle added by Prince Masud
                                        </span>
                                        <span class="infoButtom">16 May, 2022 @ 04:35</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-6 col-lg-4">
                    <div class="activity-right"></div>
                </div>
            </div>
        </div>
    </div>
</div>
