<div id="sidebar-menu">
    <ul class="metismenu" id="side-menu">
        <li>
            <a class="sideLink subSideLink maintenanceCostLink activeSubLink">
                <span>Maintenance Cost </span>
            </a>
        </li>

        <li>
            <a class="sideLink subSideLink accountConfigLink">
                <span>Account Configuration</span>
            </a>
        </li>
         <li>
            <a class="sideLink subSideLink" href="/settings">
                <span>System Settings</span>
            </a>
        </li>
         <li>
            <a class="sideLink subSideLink" href="/vehicleManager">
                <span>Vehicle Management</span>
            </a>
        </li>

       {{-- <li>
            <a class=" subSideLink" href="/">
                <span>Other Settings</span>
            </a>
        </li>
        <li>
            <a class="sideLink subSideLink" href="/">
                <span>Notification</span>
            </a>
        </li> --}}
    </ul>
</div>